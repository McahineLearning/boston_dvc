1. conda activate boston
2. code -r requirements.txt
3. pip install -r requirements.txt
4. pip install -r requirements.txt
5. code -r README.md
6. 